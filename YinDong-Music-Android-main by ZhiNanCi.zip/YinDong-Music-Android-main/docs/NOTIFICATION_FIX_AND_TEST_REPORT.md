# 通知栏点击返回应用 — 修复与测试报告

> 生成日期：2026-07-24
> 模块：通知 / 前台服务 / 播放器
> 验证方式：源码静态分析 + Gradle 编译验证（`BUILD SUCCESSFUL`）

---

## 一、问题现象

用户反馈：**从消息通知栏点击无法返回软件**，点击通知后不能正确唤醒并跳转到应用界面。

---

## 二、根因分析

### 核心缺陷：通知正文未设置 `setContentIntent()`

定位文件：[MusicPlaybackService.kt](file:///c:/Users/11832/Music/yyy/app/src/main/java/com/yindong/music/MusicPlaybackService.kt)

`buildContentPendingIntent()` 方法（用于"点击通知回到 MainActivity"）**只被挂到了 MediaSession 的 `setSessionActivity()`**，而构建通知本体的 `buildNotification()` **从未调用 `setContentIntent()`**。

```kotlin
// 修复前：builder 链里完全没有 setContentIntent
val builder = NotificationCompat.Builder(this, CHANNEL_ID)
    .setSmallIcon(...)
    .setContentTitle(title)
    .setContentText(artist)
    .setOngoing(isPlaying)
    .setSilent(true)
    .setShowWhen(false)
    .addAction(...)   // 上一首 / 播放暂停 / 下一首 / 关闭
    // ❌ 缺少 .setContentIntent(buildContentPendingIntent())
```

**为什么只在部分设备失效：**
`MediaStyle` 在 AOSP 原生系统上"可能"从 `MediaSession.setSessionActivity()` 继承点击行为，但该继承**未被 Android 规范保证**。在国产 ROM（vivo OriginOS、OPPO ColorOS、小米 HyperOS、华为 HarmonyOS、三星 OneUI）上普遍不继承，导致点击通知正文无任何响应——这与用户反馈完全吻合。

### 覆盖性核查

对全工程 `app/src/main/java` 用 `NotificationCompat.Builder | Notification.Builder` 全量检索，**确认全工程仅存在 2 处通知构造点**，均已修复：

| # | 文件 | 类型 | 修复前 setContentIntent |
|---|------|------|------------------------|
| 1 | [MusicPlaybackService.kt](file:///c:/Users/11832/Music/yyy/app/src/main/java/com/yindong/music/MusicPlaybackService.kt) | 媒体播放前台服务通知 | ❌ 缺失 |
| 2 | [FloatingLyricsService.kt](file:///c:/Users/11832/Music/yyy/app/src/main/java/com/yindong/music/FloatingLyricsService.kt) | 悬浮歌词前台服务通知 | ❌ 缺失 |

> 注：检索过程中一度有子代理报告"另有 20 处通知构造缺失"，经 `grep` 全量复核确认为**误报**（Compose 屏幕文件不会构造通知），未据此误改任何文件。

---

## 三、BUG 修复记录

### 修复 1：播放通知正文可点击回应用

文件：[MusicPlaybackService.kt](file:///c:/Users/11832/Music/yyy/app/src/main/java/com/yindong/music/MusicPlaybackService.kt#L309-L324)

```kotlin
val builder = NotificationCompat.Builder(this, CHANNEL_ID)
    .setSmallIcon(android.R.drawable.ic_media_play)
    .setContentTitle(title)
    .setContentText(artist)
    .setOngoing(isPlaying)
    .setSilent(true)
    .setShowWhen(false)
    // 点击通知正文回到 MainActivity（配合 launchMode="singleTask" 走 onNewIntent）。
    // 必须显式设置：仅靠 MediaSession.setSessionActivity() 在 vivo/OPPO/小米/华为/鸿蒙
    // 等 ROM 上不可靠，会导致点击通知栏无法唤起应用。
    .apply { buildContentPendingIntent()?.let { setContentIntent(it) } }
    .addAction(...)
```

- 复用既有 `buildContentPendingIntent()`，使用 `FLAG_UPDATE_CURRENT | FLAG_IMMUTABLE`（Android 12+ 合规）。
- 配合 `AndroidManifest` 中 `MainActivity` 的 `launchMode="singleTask"`，点击通知会复用已有实例并走 `onNewIntent`，而非重建 Activity。

### 修复 2：悬浮歌词通知正文可点击回应用

文件：[FloatingLyricsService.kt](file:///c:/Users/11832/Music/yyy/app/src/main/java/com/yindong/music/FloatingLyricsService.kt#L461-L483)

新增 `PendingIntent` import 并在 `createNotification()` 中显式设置内容 Intent（与播放通知一致的 launcher Intent + `singleTask` 复用策略）。

### 修复验证（编译）

```
> Task :app:compileDebugKotlin
BUILD SUCCESSFUL in 22m 37s
```

- 修改的两个文件 **0 编译错误**。
- 日志中的 `warning:` 均为**既有遗留告警**（`MusicViewModelxl.kt` 的 `Virtualizer` 弃用、未使用参数等），与本次修复无关，未触碰。
- 末尾的 `exit code 1` 来自沙箱拦截 Kotlin daemon 临时文件清理（发生于 `BUILD SUCCESSFUL` 之后），非代码问题。

---

## 四、静态审查发现的其他问题（按风险分级）

| 等级 | 文件 / 位置 | 描述 | 现状 | 建议 |
|------|------------|------|------|------|
| 低 | [MusicPlaybackServiceHelper.kt:18-27](file:///c:/Users/11832/Music/yyy/app/src/main/java/com/yindong/music/MusicPlaybackServiceHelper.kt#L18-L27) | `updateCover` 回退分支在服务未运行时用 `context.startService(intent)` 传 Bitmap；Android 8+ 后台启动服务会抛 `IllegalStateException`，且大封面 Bitmap 可能触发 `TransactionTooLargeException` | 已 `try-catch`，**不会崩溃**，仅静默失败 | 改用 `startForegroundService` 或直接在服务存活时走 `service?.updateCover()` 主路径；封面建议存盘后传路径而非 Bitmap |
| 信息 | [MusicViewModelxl.kt](file:///c:/Users/11832/Music/yyy/app/src/main/java/com/yindong/music/viewmodel/MusicViewModelxl.kt) 多处 | `Virtualizer` 等音频 API 弃用告警 | 仅告警 | 后续按项目规范用 native C++ 音效模块替换（符合项目约束） |
| 信息 | 服务生命周期 | `onStartCommand` / `onTaskRemoved` / `onDestroy` 清理逻辑、`MediaSession` 释放均正确 | 无问题 | 保持 |

> 说明：本次未对 4200+ 行 `MusicViewModel` 做"全量穷尽审计"——此类声称不可证伪且不诚实。上表为通知/服务热路径聚焦审查的结论。

---

## 五、测试报告

### 5.1 已完成验证（静态 + 编译）

| 项 | 结论 |
|----|------|
| 根因定位 | ✅ 通知正文未设置 `setContentIntent` |
| 修复实现 | ✅ 两处通知构造点均已补全 |
| 全工程通知构造点覆盖核查 | ✅ `grep` 确认仅 2 处，无遗漏 |
| Kotlin 编译 | ✅ `BUILD SUCCESSFUL`，修改文件 0 错误 |
| PendingIntent 标志位合规 | ✅ `FLAG_IMMUTABLE`（Android 12+） |
| Activity 复用策略 | ✅ `singleTask` + `onNewIntent`，无重建 |
| 前台服务类型声明 | ✅ `mediaPlayback` / `specialUse`，Android 10+/14+ 合规 |

### 5.2 设备实测矩阵（需在真机/模拟器执行）

> 以下为我无法在本环境代为执行的运行时验证清单，请按此矩阵实测并回填结果。

| 场景 | 操作 | 预期 | Android 版本 / 设备 |
|------|------|------|---------------------|
| 通知点击回应用 | 播放中→按 Home 退后台→点通知正文 | 应用回到前台，停留在当前界面 | 8.0 / 10 / 12 / 13 / 14 / 15 |
| 锁屏媒体控制点击 | 锁屏→点媒体卡片标题区 | 解锁后回到应用 | 12 / 13 / 14 |
| 应用已被系统回收 | 杀进程→点通知 | 应用重新启动到 MainActivity | 10 / 12 / 14 |
| 通知操作按钮 | 点上一首/播放暂停/下一首/关闭 | 对应功能生效，无闪退 | 全版本 |
| 悬浮歌词通知点击 | 开启悬浮歌词→点其通知 | 回到应用 | 12 / 14 |
| 国产 ROM 兼容 | 同上"通知点击回应用" | **重点验证** vivo / OPPO / 小米 / 华为 / 鸿蒙 |
| 车载蓝牙 AVRCP | 连车机→通知标题显示歌词行 | 车机屏正确显示 | 车机 |
| 旋转屏 / 深色模式切换 | 切换过程点通知 | 无崩溃，界面正常 | 12 / 14 |

### 5.3 稳定性重点关注项

- **闪退**：通知 PendingIntent 构造、`getLaunchIntentForPackage` 返回 null 边界（已用 `?.let` 兜底）。
- **ANR**：通知更新在主线程 `NotificationManager.notify`，`updateAll` 频率受车载歌词 1s 刷新影响，需实测长时间播放是否卡顿。
- **内存**：`coverBitmap` 大封面常驻 + 通知 `setLargeIcon`，需观察长时间播放内存曲线。

---

## 六、变更文件清单

1. [MusicPlaybackService.kt](file:///c:/Users/11832/Music/yyy/app/src/main/java/com/yindong/music/MusicPlaybackService.kt) — `buildNotification()` 补 `setContentIntent`
2. [FloatingLyricsService.kt](file:///c:/Users/11832/Music/yyy/app/src/main/java/com/yindong/music/FloatingLyricsService.kt) — 新增 `PendingIntent` import + `createNotification()` 补 `setContentIntent`

---

## 七、结论

- **已修复**：通知栏点击无法返回应用的根本原因（两处通知均未设置 `setContentIntent`），并通过编译验证。
- **建议实测**：按 5.2 矩阵在真机（尤其国产 ROM）回归，确认运行时行为符合预期。
- **待跟进**：5.x 表中"低风险"项可在后续迭代优化，当前不影响稳定性（已兜底捕获）。
